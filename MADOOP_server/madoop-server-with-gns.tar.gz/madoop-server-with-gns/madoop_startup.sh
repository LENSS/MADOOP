#! /bin/sh

# first change pwd to the current directory where this script is stored.
cd "$(dirname "$0")"


# Carry out specific functions when asked to by the system
case "$1" in
  start)
    echo "Starting Madoop"
    ./bootstrap.sh reset2  > madoop_terminal.out &
    ;;
  stop)
    echo "Stopping GNS Service"
    ./bootstrap.sh reset2  > madoop_terminal.out &
    ;;
  *)
    echo "Usage: gns-service {start|stop}"
    exit 1
    ;;
esac

exit 0



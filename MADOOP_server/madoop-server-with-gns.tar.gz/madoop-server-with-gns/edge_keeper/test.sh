#!/usr/bin/env bash

echo "Adding madoop as service at EdgeKeeper"
java -jar EdgeKeeper-cli.jar add_service madoop server

#echo "Removing madoop as service from EdgeKeeper"
#java -jar EdgeKeeper-cli.jar remove_service madoop
